package com.cg.geo;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.geojson.Feature;
import org.geojson.FeatureCollection;
import org.geojson.GeoJsonObject;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.ObjectMapper;

public class GeoJsonFileLoader {
public static List<Object> typeOfObject()  throws Exception {
	String filePath ="D:\\Users\\dumatta\\Desktop\\aus_state.geojson";
	JsonFactory factory = new JsonFactory();
	File jsonFile = new File(filePath);
	JsonParser  inputStream  = factory.createParser(jsonFile);
	GeoJsonObject object = new ObjectMapper().readValue(inputStream, GeoJsonObject.class);
    String objectType = object.getClass().getSimpleName();
    List<Object> dataList = new ArrayList<Object>();
    dataList.add(objectType);
    dataList.add(object);
    return dataList;
}
public static void main(String[] args) throws Exception{
    String objectType = (String)GeoJsonFileLoader.typeOfObject().get(0);
    FeatureCollection fc = (FeatureCollection)GeoJsonFileLoader.typeOfObject().get(1);
    List<Feature> features = fc.getFeatures();
    int featuresSize = features.size();
    
    
}
}
