package com.cg.gis;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Iterator;

import org.elasticsearch.action.bulk.BulkRequestBuilder;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.support.WriteRequest.RefreshPolicy;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.TransportAddress;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.transport.client.PreBuiltTransportClient;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;



public class ElasticBulkInsert {
	public boolean bulkInsert( String indexName, String indexType, String dataPath ) throws IOException, ParseException,UnknownHostException { 
		String host_es = "127.0.0.1";
		int id = 1;

		// Settings settings = Settings.builder().put("cluster.name",
		// "elasticsearch").build();
		Settings settings = Settings.builder().put("cluster.name", "elasticsearchpdp")
				.put("client.transport.ignore_cluster_name", true).put("client.transport.sniff", true).build();

		TransportClient client = new PreBuiltTransportClient(settings)
				.addTransportAddress(new TransportAddress(InetAddress.getByName(host_es), 9300));

		
		BulkRequestBuilder bulkRequest = client.prepareBulk();
		
		JSONParser parser = new JSONParser();
		// we know we get an array from the example data
		JSONArray jsonArray = (JSONArray) parser.parse( new FileReader( dataPath ) );
	    
		@SuppressWarnings("unchecked")
		Iterator<JSONObject> it = jsonArray.iterator();
	    
	    while( it.hasNext() ) {
	    	JSONObject json = it.next();
	    	
	    	
			bulkRequest.setRefreshPolicy( RefreshPolicy.IMMEDIATE ).add( 
				client.prepareIndex( indexName, indexType,"1" )
					.setSource( json.toJSONString(), XContentType.JSON )
			);
			System.out.println("Insert document: " + json.toJSONString());
	    }
        
		BulkResponse bulkResponse = bulkRequest.get();
		if ( bulkResponse.hasFailures() ) {
			System.out.println( "Bulk insert failed: " + bulkResponse.buildFailureMessage());
			return false;
		}
		
		return true;
	}
	
	// resolve maven specific path for resources
    private static String getRelativeResourcePath( String resource ) throws FileNotFoundException {
		
		if( resource == null || resource.equals("") ) throw new IllegalArgumentException( resource );
		
		URL url = ElasticBulkInsert.class.getClassLoader().getResource( resource );
		System.out.println(url);
		
		if( url == null ) throw new FileNotFoundException( resource );
		
		return url.getPath();
	}

	public static void main(String[] args) throws Exception {
		ElasticBulkInsert elasticBulkInsert = new ElasticBulkInsert();
	
		elasticBulkInsert.bulkInsert("bulkdata", "doc",getRelativeResourcePath("data.json"));
	}
}
