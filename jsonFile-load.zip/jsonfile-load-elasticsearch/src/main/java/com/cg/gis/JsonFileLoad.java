package com.cg.gis;

import static org.elasticsearch.common.xcontent.XContentFactory.jsonBuilder;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Date;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.TransportAddress;
import org.elasticsearch.rest.RestStatus;
import org.elasticsearch.transport.client.PreBuiltTransportClient;

public class JsonFileLoad {
	public static void writeaToEs() throws UnknownHostException, IOException {

		String host_es = "127.0.0.1";

		// Settings settings = Settings.builder().put("cluster.name",
		// "elasticsearch").build();
		Settings settings = Settings.builder().put("cluster.name", "elasticsearchpdp")
				.put("client.transport.ignore_cluster_name", true).put("client.transport.sniff", true).build();

		TransportClient client = new PreBuiltTransportClient(settings)
				.addTransportAddress(new TransportAddress(InetAddress.getByName(host_es), 9300));

		IndexResponse response = client.prepareIndex("twitter", "_doc", "1")
				.setSource(jsonBuilder().startObject().field("user", "kimchy").field("postDate", new Date())
						.field("message", "trying out Elasticsearch").endObject())
				.get();

		// get
		GetResponse getResp = client.prepareGet("twitter", "_doc", "1").get();
		System.out.println(getResp);
		// delete
		/*
		 * DeleteResponse delResp = client.prepareDelete("twitter", "_doc", "1").get();
		 * System.out.println(delResp);
		 */

		String _index = response.getIndex();
		// Type name
		String _type = response.getType();
		// Document ID (generated or not)
		String _id = response.getId();
		// Version (if it's the first time you index this document, you will get: 1)
		long _version = response.getVersion();
		// status has stored current instance statement.
		RestStatus status = response.status();
		System.out.println(
				"index:" + _index + " Type:" + _type + "Id:" + _id + " version:" + _version + " status:" + status);

	}

	public static void main(String[] args) throws Exception {
		JsonFileLoad.writeaToEs();
		System.out.println("json format data inserted....");
		System.out.println("success");
	}
}
