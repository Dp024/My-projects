package com.cg.gis;

import static org.elasticsearch.action.support.WriteRequest.RefreshPolicy.IMMEDIATE;
import static org.elasticsearch.common.xcontent.XContentFactory.jsonBuilder;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.elasticsearch.action.admin.indices.create.CreateIndexResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.TransportAddress;
import org.elasticsearch.common.xcontent.XContentFactory;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.transport.client.PreBuiltTransportClient;


public class GeoJsonLoader {
	public static Client client() throws UnknownHostException  {
		String host_es = "127.0.0.1";
		Settings settings = Settings.builder().put("cluster.name", "elasticsearchpdp")
				.put("client.transport.ignore_cluster_name", true).put("client.transport.sniff", true).build();
		TransportClient client = new PreBuiltTransportClient(settings)
				.addTransportAddress(new TransportAddress(InetAddress.getByName(host_es), 9300));
		return client;
		
	}
	public void geoShapeElastic() throws Exception{
	String mapping = XContentFactory.jsonBuilder().startObject().startObject("type1")
            .startObject("properties").startObject("location")
            .field("type", "geo_shape")
            .field("tree", "quadtree")
            .endObject().endObject()
            .endObject().endObject().string();

	client().admin().indices().prepareCreate("test").addMapping("type1", mapping, XContentType.JSON).execute().actionGet();
	
	
	client().prepareIndex("test", "type1", "blakely").setSource(jsonBuilder().startObject()
            .field("name", "Blakely Island")
            .startObject("location")
            .field("type", "polygon")
            .startArray("coordinates").startArray()
            .startArray().value(-122.83).value(48.57).endArray()
            .startArray().value(-122.77).value(48.56).endArray()
            .startArray().value(-122.79).value(48.53).endArray()
            .startArray().value(-122.83).value(48.57).endArray() // close the polygon
            .endArray().endArray()
            .endObject()
            .endObject()).setRefreshPolicy(IMMEDIATE).get();
	
    }
	public static void main(String[] args) throws Exception {
		GeoJsonLoader geoJsonLoader = new GeoJsonLoader();
		geoJsonLoader.geoShapeElastic();
		System.out.println("geo shape successfully loaded into elastic....");
	}
}