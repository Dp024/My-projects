package com.cg.dao;

import com.cg.model.EmployeeCredentials;

public interface ILoginDAO {
public String roleType(EmployeeCredentials employeeCredentials);
public int updateUserCredentials(String userName, String password);
}