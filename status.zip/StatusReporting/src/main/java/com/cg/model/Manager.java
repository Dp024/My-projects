package com.cg.model;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Proxy;
import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name="manager")
@Proxy(lazy=false)
public class Manager {
@Id
@Column(name="manager_id")
private int managerId;
@Column(name = "location", nullable=false)
private String location;
@OneToMany(mappedBy="manager")
private Set<TeamMember> teamMembers;
public int getManagerId() {
	return managerId;
}
public void setManagerId(int managerId) {
	this.managerId = managerId;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public Set<TeamMember> getTeamMembers() {
	return teamMembers;
}
public void setTeamMembers(Set<TeamMember> teamMembers) {
	this.teamMembers = teamMembers;
}


}