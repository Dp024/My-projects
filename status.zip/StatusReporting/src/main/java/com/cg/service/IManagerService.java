package com.cg.service;

import java.util.List;

import com.cg.model.Employee;
import com.cg.model.StatusReporting;
import com.cg.model.TeamMember;

public interface IManagerService {
public Employee searchEmployee(int id);
public TeamMember addTeamMember(Employee e,String user);
public List<TeamMember> teamMembersList(String user);
public void removeTeamMember(int id);
public List<StatusReporting> teamMeberStatusById(int id);
public StatusReporting memberStatusByStatusId(int statusId);
public void update(StatusReporting status);
}
