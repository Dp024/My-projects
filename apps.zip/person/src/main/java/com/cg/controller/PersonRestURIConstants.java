package com.cg.controller;

public class PersonRestURIConstants {

	public static final String GET_PERSON = "/rest/person/{id}";
	public static final String GET_ALL_PERSON = "/rest/persons";
	public static final String CREATE_PERSON = "/rest/person/create";
	public static final String DELETE_PERSON = "/rest/person/delete/{id}";
}
