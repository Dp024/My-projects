package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entities.Patient;


@Repository
@Transactional
public class PatientDAOImpl implements IPatientDAO {


	
	// Below annotation is required to inject auto created entityManager from
	// entityManagerFactory
	@PersistenceContext
	private EntityManager entityManager;
	
	

	public void addPatient(Patient p) {
		
		entityManager.persist(p);
		entityManager.flush();
		System.out.println("successfully added");

	}

	@Override
	public void updatePatient(Patient p) {
		entityManager.merge(p);


	}

	@Override
	public List<Patient> listPatients() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Patient getPatientById(int id) {
		// TODO Auto-generated method stub
		Patient patient = entityManager.find(Patient.class,id);
		System.out.println("dao:"+ patient);
		return patient;
	}

	@Override
	public void removePatient(int id) {
		// TODO Auto-generated method stub
		Patient patient=entityManager.find(Patient.class,id);
		entityManager.remove(patient);

	}

}
