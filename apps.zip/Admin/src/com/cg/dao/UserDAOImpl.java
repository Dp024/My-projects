package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entities.UserCredentials;
import com.cg.entities.UserRegistration;

@Repository
@Transactional
public class UserDAOImpl implements IUserDAO {
	

	
	// Below annotation is required to inject auto created entityManager from
	// entityManagerFactory
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public boolean authenticateUser(UserCredentials user) {
		int id = 0;
		Query query=entityManager.createQuery("select distinct userId from UserRegistration where username=:username and password=:password");
		query.setParameter("username",user.getUserName().trim());
		query.setParameter("password",user.getPassword().trim());
		try{
		     id=(Integer) query.getSingleResult();
			}catch(NoResultException e){
				return false;
			}
			if(id>0)
			return true;
			else
			return false;
		}
	

	@Override
	public int addUser(UserRegistration user) {
		int count = 0;
		entityManager.persist(user);
		entityManager.flush(); // required to reflect changes on database
		count++;
		System.out.println("user successfully registered");
	    return count;
	}


	
}
