package com.cg.dao;

import com.cg.entities.UserCredentials;
import com.cg.entities.UserRegistration;



public interface IUserDAO {
	public boolean authenticateUser(UserCredentials user);
	public int addUser(UserRegistration user);

}
