package com.cg.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table
public class Patient {

@Id
@GeneratedValue(strategy=GenerationType.SEQUENCE)	
private int patientId;

@NotEmpty(message="Name is required")
@Size(max=15,message="Name should not be more than 15 characters ")
@Column
private String patientName;

@NotEmpty(message="Phone no required")
@Size(min=10,max=10,message="phone number lenght must be 10 character")
@Pattern(regexp="[0-9]{10}", message="Pattern Violated: Phone number should be Number Only")
@Column
private String patientPhone;

@NotEmpty(message="Address is required")
@Size(max=100,message="address should not be more than 100 characters ")
@Column
private String patientAddress;
public int getPatientId() {
	return patientId;
}
public void setPatientId(int patientId) {
	this.patientId = patientId;
}
public String getPatientName() {
	return patientName;
}
public void setPatientName(String patientName) {
	this.patientName = patientName;
}
public String getPatientPhone() {
	return patientPhone;
}
public void setPatientPhone(String patientPhone) {
	this.patientPhone = patientPhone;
}
public String getPatientAddress() {
	return patientAddress;
}
public void setPatientAddress(String patientAddress) {
	this.patientAddress = patientAddress;
}

public Patient() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Patient [patientId=" + patientId + ", patientName=" + patientName
			+ ", patientPhone=" + patientPhone + ", patientAddress="
			+ patientAddress + "]";
}

}
