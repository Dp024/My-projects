package com.cg.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

public class UserCredentials implements Serializable {
	private static final long serialVersionUID = 1L;
	@NotEmpty(message="User Name is required")
	@Size(min=8,max=8,message="User Name must be 8 characters")
	@Column
	private String userName;
	@NotEmpty(message="password is required")
	@Size(min=8,max=8,message="password must be 8 characters")
	@Column
	private String password;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public UserCredentials(String userName, String password) {
		super();
		this.userName = userName;
		this.password = password;
	}
	
	public UserCredentials(){}
}
