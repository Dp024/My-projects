package com.cg.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table
public class UserRegistration implements Serializable{
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int userId;
	
	@NotEmpty(message="Name is required")
	@Size(min=8,max=15,message="Name 8 to 15 characters")
	@Column
	private String fullName;
	
	@NotEmpty(message="User Name is required")
	@Size(min=8,max=8,message="User Name must be 8 characters")
	@Column
	private String userName;
	@NotEmpty(message="password is required")
	@Size(min=8,max=8,message="password must be 8 characters")
	@Column
	private String password;
    
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public UserRegistration(int userId, String fullName, String userName,
			String password) {
		super();
		this.userId = userId;
		this.fullName = fullName;
		this.userName = userName;
		this.password = password;
	}

	public UserRegistration(){}
	
	
}
