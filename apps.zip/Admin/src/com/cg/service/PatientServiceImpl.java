package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.dao.IPatientDAO;
import com.cg.entities.Patient;

@Component
public class PatientServiceImpl implements IPatientService {
	
	@Autowired
	private IPatientDAO patientDao;

	@Override
	public void addPatient(Patient p) {
		// TODO Auto-generated method stub
      patientDao.addPatient(p);
      }

	@Override
	public void updatePatient(Patient p) {
		// TODO Auto-generated method stub
      patientDao.updatePatient(p);
	}

	@Override
	public List<Patient> listPatients() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Patient getPatientById(int id) {
		// TODO Auto-generated method stub
		return patientDao.getPatientById(id);
	}

	@Override
	public void removePatient(int id) {
		// TODO Auto-generated method stub
        patientDao.removePatient(id);
	}

}
