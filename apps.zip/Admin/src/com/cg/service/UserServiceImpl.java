package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.dao.IUserDAO;
import com.cg.entities.UserCredentials;
import com.cg.entities.UserRegistration;


@Component
public class UserServiceImpl implements IUserService {
	@Autowired
    private IUserDAO userDao;
	@Override
	public boolean checkUser(UserCredentials user) {
		
		return userDao.authenticateUser(user);
	}

	@Override
	public int registerUser(UserRegistration user) {
      int count = userDao.addUser(user);
      return count;
	}

}
