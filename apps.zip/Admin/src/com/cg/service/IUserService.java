package com.cg.service;

import com.cg.entities.UserCredentials;
import com.cg.entities.UserRegistration;



public interface IUserService {
	public boolean checkUser(UserCredentials user);
	public int registerUser(UserRegistration user);
}
