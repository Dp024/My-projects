package com.cg.service;

import java.util.List;

import com.cg.entities.Patient;

public interface IPatientService {

	public void addPatient(Patient p);
	public void updatePatient(Patient p);
	public List<Patient> listPatients();
	public Patient getPatientById(int id);
	public void removePatient(int id);
}
