package com.cg.validator;

import javax.validation.constraints.Pattern;


import org.hibernate.validator.constraints.NotEmpty;

public class PatientSearchValidator {

@NotEmpty(message="Id required")
@Pattern(regexp="^(0|[1-9][0-9]*)$", message="Id should be number Only!!!")	
private String patientId;

public String getPatientId() {
	return patientId;
}

public void setPatientId(String patientId) {
	this.patientId = patientId;
}



}
