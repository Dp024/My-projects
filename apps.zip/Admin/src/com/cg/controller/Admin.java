package com.cg.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.entities.Patient;
import com.cg.entities.UserCredentials;
import com.cg.entities.UserRegistration;
import com.cg.service.IPatientService;
import com.cg.service.IUserService;
import com.cg.validator.PatientSearchValidator;


@Controller
public class Admin {

	@Autowired
	private IUserService service;
	@Autowired
	private IPatientService patientService;
	
	@RequestMapping(value="home", method=RequestMethod.GET)
	public String loginForm(Model model){
		
	    UserCredentials user = new UserCredentials();
		model.addAttribute("user1", user);
		
		return "login";
	}
	@RequestMapping(value="register", method=RequestMethod.GET)
	public String registerForm(Model model){
		
	    UserRegistration user = new UserRegistration();
		model.addAttribute("user", user);
		
		return "registration";
	}
	@RequestMapping(value="patientRegistration",method=RequestMethod.GET)
	public String patientRegisterForm(Model model)
	{
		Patient patient = new Patient();
		model.addAttribute("patient",patient);
		return "patientForm";
		
	}
	@RequestMapping("patientIndex")
	public String patientCrudIndexPage(){
		return "patientCRUD";
	}
	@RequestMapping(value="searchPatient",method=RequestMethod.GET)
	public String searchPatientForm(Model model)
	{
		PatientSearchValidator psv = new PatientSearchValidator();
		model.addAttribute("psv",psv);
		return "search";
		
	}

	@RequestMapping(value="authenticateUser",method=RequestMethod.POST)
	public String checkUser(@ModelAttribute("user1") @Valid UserCredentials user,BindingResult result,Model model){
		
		if(result.hasErrors()){
		
		return "login";
		}
		
		if(service.checkUser(user)){
	    
		return "redirect:patientIndex.do";
		}
		else{
		model.addAttribute("UserDataNotFound","Invalid username or password");
		
		return "login";
		}
		
	}
	@RequestMapping(value="regValidation",method=RequestMethod.POST)
	public String registerUser(@ModelAttribute("user") @Valid UserRegistration user,BindingResult result,Model model){
		
		if(result.hasErrors()){
			
		return "registration";
		}
		
		if(service.registerUser(user)>0){
	    String name=user.getFullName();
	    model.addAttribute("msg","hi "+name+" you are successfully registered!!!");
		return "success";
		}
		else{
	     return "registration";
		}
		
	}
	@RequestMapping(value="patientValidate",method=RequestMethod.POST)
	public String addPatient(@ModelAttribute("patient") @Valid Patient patient,BindingResult result,Model model) throws Exception{
	
		if(result.hasErrors()){
			
		return "patientForm";
		}
		
		else{
		   System.out.println(patient);
		   patientService.addPatient(patient);
		   int id = patient.getPatientId();
		   model.addAttribute("id",id);
		   return "addSuccess";
		}
	
	}
	@RequestMapping(value="searchValidation", method=RequestMethod.GET)
	public String retrievePatient(@ModelAttribute("psv") @Valid PatientSearchValidator psv,BindingResult result,Model model) throws Exception{
	if(result.hasErrors()){
		return "search";
	}
	else{
		int id = Integer.parseInt(psv.getPatientId().trim());
		Patient patientData = patientService.getPatientById(id);
		System.out.println(patientData);
		if(patientData!=null){
		model.addAttribute("patientData",patientData);
		return "search";
		}
		else{
			model.addAttribute("patientDataNotFound","No Patient Found with given Id.Please, Enter correct id.");
			return "search";
		}
	}
}
}

