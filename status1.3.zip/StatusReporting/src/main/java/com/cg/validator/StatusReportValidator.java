package com.cg.validator;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Component
public class StatusReportValidator {
public int statusId;
@NotEmpty(message="task name required")
public String task;
@NotEmpty(message="status required")
public String status;
@NotEmpty(message="comments required")
public String comments;
public String getTask() {
	return task;
}
public void setTask(String task) {
	this.task = task;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getComments() {
	return comments;
}
public void setComments(String comments) {
	this.comments = comments;
}
public int getStatusId() {
	return statusId;
}
public void setStatusId(int statusId) {
	this.statusId = statusId;
}


}
