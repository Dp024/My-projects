package com.cg.service;


import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.dao.IManagerDAO;
import com.cg.model.Employee;
import com.cg.model.TeamMember;

@Service

public class ManagerServiceImpl implements IManagerService {

	private IManagerDAO managerDao;
	
	public void setManagerDao(IManagerDAO managerDao) {
		this.managerDao = managerDao;
	}
	@Override
	public Employee searchEmployee(int id) {
		
		return managerDao.retrieveEmployee(id);
	}
	@Override
	public TeamMember addTeamMember(Employee e,String user) {
	    return managerDao.addTeamMember(e, user);
	}
	@Override
	public List<TeamMember> teamMembersList(String user) {
		// TODO Auto-generated method stub
		return managerDao.teamMembersList(user);
	}
	@Override
	public void removeTeamMember(int id) {
		// TODO Auto-generated method stub
		this.managerDao.removeTeamMember(id);
	}

}
