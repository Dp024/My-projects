package com.cg.service;

import java.util.List;

import com.cg.model.StatusReporting;

import com.cg.validator.StatusReportValidator;

public interface ITeamMemberService {
	public StatusReporting addStatus(StatusReportValidator srv,String user);
	public List<StatusReporting> statusList(String user);
	public StatusReporting getStatusById(int statusId);
	public void update(StatusReporting status);
}
