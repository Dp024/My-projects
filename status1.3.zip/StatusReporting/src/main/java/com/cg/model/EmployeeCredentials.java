
package com.cg.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.Proxy;
import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name="employee_credentials")
@Proxy(lazy=false)
public class EmployeeCredentials {
@Id
@Column(name="employee_id")
private int employeeId;
@Column(name="username",unique= true, nullable=false)
private String userName;
@Column(name="password",nullable=false)
private String password;
@OneToOne
@PrimaryKeyJoinColumn
private Employee employee;
public int getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(int employeeId) {
	this.employeeId = employeeId;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public Employee getEmployee() {
	return employee;
}
public void setEmployee(Employee employee) {
	this.employee = employee;
}
@Override
public String toString() {
	return "EmployeeCredentials [employeeId=" + employeeId + ", userName="
			+ userName + ", password=" + password + ", employee=" + employee
			+ "]";
}


}
