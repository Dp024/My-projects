package com.cg.dao;



import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.model.EmployeeCredentials;

@Repository
public class LoginDAOImpl implements ILoginDAO {
    
	@Autowired
    private SessionFactory sessionFactory;	
	@Override
	public String roleType(EmployeeCredentials employeeCredentials) {
		Session session = this.sessionFactory.openSession();
		//Query query = session.createQuery("from EmployeeCredentials where userName=:userName and password=:password");
		Query query=session.createQuery("select e.role from Employee e where (select ec.employeeId from EmployeeCredentials ec where ec.userName=:userName and ec.password=:password)=e.employeeId)");
		query.setParameter("userName", employeeCredentials.getUserName());
		query.setParameter("password",employeeCredentials.getPassword());
		List list = query.list();
		session.close();
		System.out.println(list);
		if(list.size()>0){
		return (String)list.get(0);
		}
		else{
			return "default";
		}
	
	}
	@Override
	public int updateUserCredentials(String userName, String password) {
		Session session = this.sessionFactory.openSession();
		Query userUpdate = session.createQuery("update EmployeeCredentials e set e.password=? where e.userName=?");
		userUpdate.setParameter(0,password.trim());
		userUpdate.setParameter(1,userName.trim());
		int count = userUpdate.executeUpdate();
		session.close();
		return count;
	}

}

