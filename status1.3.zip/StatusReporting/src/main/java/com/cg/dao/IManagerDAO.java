package com.cg.dao;

import java.util.List;

import com.cg.model.Employee;
import com.cg.model.TeamMember;

public interface IManagerDAO {
public Employee retrieveEmployee(int id);
public TeamMember addTeamMember(Employee e,String user);
public List<TeamMember> teamMembersList(String user);
public void removeTeamMember(int id);
}

