package com.cg.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.dao.ITeamMemberDAO;
import com.cg.model.StatusReporting;

import com.cg.validator.StatusReportValidator;

@Service
public class TeamMemberServiceImpl implements ITeamMemberService {
private ITeamMemberDAO teamMemberDao;
public void setTeamMemberDao(ITeamMemberDAO teamMemberDao) {
	this.teamMemberDao = teamMemberDao;
}
@Override
public StatusReporting addStatus(StatusReportValidator srv,String user) {
	// TODO Auto-generated method stub
	return this.teamMemberDao.addStatus(srv,user);
}
@Override
public List<StatusReporting> statusList(String user) {
	// TODO Auto-generated method stub
	return this.teamMemberDao.statusList(user);
}
@Override
public StatusReporting getStatusById(int statusId) {
	// TODO Auto-generated method stub
	return this.teamMemberDao.getStatusById(statusId);
}

}
