package com.cg.dao;

import java.util.List;

import com.cg.model.StatusReporting;

import com.cg.validator.StatusReportValidator;

public interface ITeamMemberDAO {
public StatusReporting addStatus(StatusReportValidator srv,String user);
public List<StatusReporting> statusList(String user);
public StatusReporting getStatusById(int statusId);
}
