package com.cg.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.cg.model.StatusReporting;
import com.cg.model.TeamMember;
import com.cg.validator.StatusReportValidator;
@Repository
@Transactional
public class TeamMemberDAOImpl implements ITeamMemberDAO {
	
	@Autowired
	private StatusReporting status;
	
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
	}

	@Override
	public StatusReporting addStatus(StatusReportValidator srv,String user) {
		Session session = this.sessionFactory.getCurrentSession();
		Query query = session.createQuery("select employeeId from EmployeeCredentials where userName=:user");
		query.setString("user", user);
		int memberId =(Integer)query.list().get(0);
		TeamMember member = (TeamMember)session.load(TeamMember.class,memberId);
		status.setDate(new java.sql.Date(new java.util.Date().getTime()));
		status.setTask(srv.getTask());
		status.setStatus(srv.getStatus());
		status.setComments(srv.getComments());
		status.setMember(member);
		member.getStatus().add(status);
		session.save(status);
		System.out.println("status inserted....");
		
		return status;
		
		
	}

	@Override
	public List<StatusReporting> statusList(String user) {
		Session session = this.sessionFactory.getCurrentSession();
		Query query = session.createQuery("select employeeId from EmployeeCredentials where userName=:user");
		query.setString("user", user);
		int memberId =(Integer)query.list().get(0);
		System.out.println(memberId);
		Query statusListQuery = session.createQuery("from StatusReporting s where s.member=:memberId");
		statusListQuery.setInteger("memberId",memberId);
		List<StatusReporting> statusList = statusListQuery.list();
		
		for(StatusReporting p : statusList){
			System.out.println("status List::"+p);
			System.out.println(p.getDate());
			System.out.println(p.getStatus());
		}
		return statusList;
	}

	@Override
	public StatusReporting getStatusById(int statusId) {
		Session session = this.sessionFactory.getCurrentSession();	
		int id = statusId;
		Query statusById = session.createQuery("from StatusReporting s where s.statusId=:statusId ");
		statusById.setInteger("statusId", id);
		
		List<StatusReporting> editStatus=statusById.list();
		System.out.println(editStatus);
		
        return editStatus.get(0);
	}
}
