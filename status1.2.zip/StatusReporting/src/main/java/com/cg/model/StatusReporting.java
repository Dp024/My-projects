package com.cg.model;



import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Proxy;
import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name = "status_report")
@Proxy(lazy = false)
public class StatusReporting {

	@Id
	@Column(name="STATUS_ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int statusId;
	@Column(name="STATUS_DATE")
	private Date date;
	@Column(name="TASK")
	private String task;
	@Column(name="STATUS")
	private String status;
	@Column(name="COMMENTS")
	private String comments;
	@ManyToOne
	@JoinColumn(name = "member_id")
	private TeamMember member;
	public int getStatusId() {
		return statusId;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getTask() {
		return task;
	}
	public void setTask(String task) {
		this.task = task;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public TeamMember getMember() {
		return member;
	}
	public void setMember(TeamMember member) {
		this.member = member;
	}
	public void setStatusId(int statusId) {
		this.statusId = statusId;
	}
	

	
}
