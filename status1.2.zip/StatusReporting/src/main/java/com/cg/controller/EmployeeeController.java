package com.cg.controller;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.model.Employee;
import com.cg.model.StatusReporting;
import com.cg.model.TeamMember;
import com.cg.service.IManagerService;
import com.cg.service.ITeamMemberService;
import com.cg.validator.EmployeeSearchValidator;
import com.cg.validator.StatusReportValidator;


@Controller
public class EmployeeeController {
    @Autowired
    private StatusReportValidator srv;
	@Autowired
	private EmployeeSearchValidator esv;
	@Autowired
	private TeamMember teamMember;
    private IManagerService managerService;
	@Autowired(required=true)
	@Qualifier(value="managerService")
	public void setManagerService(IManagerService managerService) {
		this.managerService = managerService;
	}
	private ITeamMemberService teamMemberService;
	@Autowired(required=true)
	@Qualifier(value="teamMemberService")
	public void setTeamMemberService(ITeamMemberService teamMemberService){
		this.teamMemberService=teamMemberService;
	}
	
	@RequestMapping(value = "manager")
	public String loginPage(Model model,HttpSession session) {
	    String userName = (String)session.getAttribute("user");
	    model.addAttribute("teamMembersList",this.managerService.teamMembersList(userName));
		model.addAttribute("esv",esv);
	    return "teamMemberAdd";
	}
	@RequestMapping(value="member")
	public String memberPage(Model model, HttpSession session)
	{
	String userName = (String)session.getAttribute("user");
	model.addAttribute("statusList",this.teamMemberService.statusList(userName));
	model.addAttribute("srv",srv);
	return "teamMemberStatus";	
	}
	@RequestMapping(value="removeTeamMember")
	public String removeTeamMember(@RequestParam(value="empId") int empId){
		System.out.println(empId);
		this.managerService.removeTeamMember(empId);
		return "redirect:manager.do";
	}
	@RequestMapping(value="addTeamMember", method=RequestMethod.GET)
	public String retrieveEmployee(@ModelAttribute("esv") @Valid EmployeeSearchValidator esv,BindingResult result,Model model,HttpSession session) throws Exception{
	if(result.hasErrors()){
		return "teamMemberAdd";
	}
	else{
		int id = Integer.parseInt(esv.getEmpId().trim());
		System.out.println(id);
		Employee empData = managerService.searchEmployee(id);
		System.out.println(empData);

		Integer managerCode = empData.getManagerCode();
		if(managerCode==null){
			String user = (String)session.getAttribute("user");
			TeamMember memberData = managerService.addTeamMember(empData,user);
			 model.addAttribute("TeamMemberData",memberData);
			 return "redirect:manager.do";
		}
		else{
			model.addAttribute("empData", "employee already assigned with manager. Please enter another employee id");
			return "teamMemberAdd";
		}
		
		
	}
}
	@RequestMapping(value="addStatus", method=RequestMethod.GET)
	public String status(@ModelAttribute("srv") @Valid StatusReportValidator srv,BindingResult result,Model model,HttpSession session) throws Exception{
	if(result.hasErrors()){
		
		return "teamMemberStatus";
	}
	 String user = (String)session.getAttribute("user");
	 System.out.println(srv.getStatus());
	 StatusReporting reportData = this.teamMemberService.addStatus(srv,user); 
	 return "redirect:member.do";
}
	@RequestMapping(value="editStatus")
	public String editStatus(@ModelAttribute("srv") @Valid StatusReportValidator srv,BindingResult result,@RequestParam(value="statusId") int statusId,Model model){
		System.out.println(statusId);
		model.addAttribute("statusData", this.teamMemberService.getStatusById(statusId).getTask());
		model.addAttribute("esv",esv);

		return "teamMemberStatus";
	}
}
