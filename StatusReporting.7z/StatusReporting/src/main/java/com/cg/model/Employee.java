package com.cg.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Proxy;
import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name="employee")
@Proxy(lazy=false)
public class Employee {
@Id
@Column(name="employee_id")
private int employeeId;
@Column(name="emp_name", nullable=false)
private String employeeName;
@Column(name="role",nullable=false)
private String role;
@Column(name="mgr")
private Integer managerCode;

@OneToOne(mappedBy="employee")

private EmployeeCredentials employeeCredentials;
public int getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(int employeeId) {
	this.employeeId = employeeId;
}
public String getEmployeeName() {
	return employeeName;
}
public void setEmployeeName(String employeeName) {
	this.employeeName = employeeName;
}
public String getRole() {
	return role;
}
public void setRole(String role) {
	this.role = role;
}
public Integer getManagerCode() {
	return managerCode;
}
public void setManagerCode(Integer managerCode) {
	this.managerCode = managerCode;
}

public EmployeeCredentials getEmployeeCredentials() {
	return employeeCredentials;
}
public void setEmployeeCredentials(EmployeeCredentials employeeCredentials) {
	this.employeeCredentials = employeeCredentials;
}



	
}
