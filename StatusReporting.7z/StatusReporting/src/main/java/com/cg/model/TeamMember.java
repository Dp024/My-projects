package com.cg.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Proxy;
import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name="team_member")
@Proxy(lazy=false)
public class TeamMember {
@Id
@Column(name="member_id")
private int memberId;
@Column(name="member_name",nullable=false)
private String memberName;
@ManyToOne
@JoinColumn(name="mgr_id")
private Manager manager;
public int getMemberId() {
	return memberId;
}
public void setMemberId(int memberId) {
	this.memberId = memberId;
}
public String getMemberName() {
	return memberName;
}
public void setMemberName(String memberName) {
	this.memberName = memberName;
}
public Manager getManager() {
	return manager;
}
public void setManager(Manager manager) {
	this.manager = manager;
}

}
