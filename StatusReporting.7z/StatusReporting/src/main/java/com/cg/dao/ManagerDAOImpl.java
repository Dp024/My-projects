package com.cg.dao;



import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.model.Employee;
import com.cg.model.Manager;

import com.cg.model.TeamMember;

@Repository
@Transactional
public class ManagerDAOImpl implements IManagerDAO {
@Autowired
private TeamMember teamMember;
@Autowired
private Manager manager;
private SessionFactory sessionFactory;

public void setSessionFactory(SessionFactory sf){
	this.sessionFactory = sf;
}

@Override
public Employee retrieveEmployee(int id) {
		
		Session session = this.sessionFactory.getCurrentSession();		
		Employee employee = (Employee) session.load(Employee.class, new Integer(id));
		
		return employee;
	}

	@Override
	public TeamMember addTeamMember(Employee e,String user) {
		Session session = this.sessionFactory.getCurrentSession();
		Query query = session.createQuery("select employeeId from EmployeeCredentials where userName=:user");
		query.setString("user", user);
		Integer mgrId =(Integer)query.list().get(0);
		
		Manager manager=(Manager)session.load(Manager.class,mgrId);
	    System.out.println(e.getEmployeeName());
		teamMember.setMemberId(e.getEmployeeId());
		teamMember.setMemberName(e.getEmployeeName());
		teamMember.setManager(manager);
		manager.getTeamMembers().add(teamMember);
		session.save(teamMember);
		System.out.println("1 row inserted");
		Integer memberId=teamMember.getMemberId();
		Query employeeUpdate = session.createQuery("update Employee e set e.managerCode=? where e.employeeId=?");
		employeeUpdate.setParameter(0,mgrId);
		employeeUpdate.setParameter(1,memberId );
	    employeeUpdate.executeUpdate();
		
	
		
		return teamMember;
		
	}

	@Override
	public List<TeamMember> teamMembersList(String user) {
		Session session = this.sessionFactory.getCurrentSession();
		Query query = session.createQuery("select employeeId from EmployeeCredentials where userName=:user");
		query.setString("user", user);
		Integer mgrId =(Integer)query.list().get(0);
		System.out.println(mgrId);
		Query teamListQuery = session.createQuery("from TeamMember where manager=:mgrId");
		teamListQuery.setInteger("mgrId",mgrId);
		List<TeamMember> teamMemberList = teamListQuery.list();
		
		for(TeamMember p : teamMemberList){
			System.out.println("Person List::"+p);
		}
		return teamMemberList;
	}

	@Override
	public void removeTeamMember(int id) {
		Session session = this.sessionFactory.getCurrentSession();	
		Query memberDelete = session.createQuery("delete TeamMember t where  t.memberId=:memberId");
		memberDelete.setParameter("memberId", id);
		memberDelete.executeUpdate();
		Employee employee = (Employee)session.load(Employee.class, id);
		employee.setManagerCode(null);
		session.saveOrUpdate(employee);
		/*Query employeeUpdate = session.createQuery("update Employee e set e.managerCode=? where e.employeeId=?");
		employeeUpdate.setParameter(0,null);
		employeeUpdate.setParameter(1,id);
	    employeeUpdate.executeUpdate();*/
	
		
		
		
	}

}
