package com.cg.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.service.ILoginService;
import com.cg.validator.UserCredentialsValidator;
import com.cg.validator.UserLoginValidator;

@Controller
public class LoginController {

	@Autowired
	private UserLoginValidator userLoginValidator;
	@Autowired
	private UserCredentialsValidator ucv;
	@Autowired
	private ILoginService loginService;

	@RequestMapping(value = "home")
	public String loginPage(Model model) {
		model.addAttribute("userLogin", userLoginValidator);
		return "Login";
	}
	@RequestMapping(value = "logout")
	public String logout(HttpServletRequest request) {
   
        HttpSession httpSession = request.getSession();
        httpSession.invalidate();
        return "redirect:home.do";
    }
	@RequestMapping(value="changePassword")
	public String changePassowordPage(Model model,HttpSession session){
		model.addAttribute("ucv",ucv);
		String userName = (String)session.getAttribute("user");
		model.addAttribute("userName",userName);
		
		return "updateUserCredentials";
	}
   
	@RequestMapping(value="loginValidation", method = RequestMethod.POST )
	public String checkUser(Model model,@ModelAttribute("userLogin") @Valid UserLoginValidator userLogin, BindingResult result,HttpSession session)
	{
		
	if(result.hasErrors()){
			return "Login";
	}
	String s = loginService.userType(userLogin)  ;
	if(s.equals(userLogin.getUserType().trim())){
		session.setAttribute("user", userLogin.getUserName());
	}
	 return s.trim().equals(userLogin.getUserType())? "redirect:"+s+".do" : "default";
	}
	@RequestMapping(value="credentialUpdateValidation", method = RequestMethod.POST )
	public String updateCredentials(Model model,@ModelAttribute("ucv") @Valid UserCredentialsValidator ucv, BindingResult result,HttpSession session)
	{
		
	if(result.hasErrors()){
		    String userName = (String)session.getAttribute("user");
			model.addAttribute("userName", userName);
			System.out.println("result has errors");
		    return "updateUserCredentials";
	}
	 System.out.println("result has no errors");
	 String userName = ucv.getUserName();
	 String password = ucv.getPassword();
	 int count = loginService.updateUserCredentials(userName, password);
	 if(count>0){
		 model.addAttribute("userData","you are successfully update your password.");
		 return "updateUserCredentials";
	 }
	 else{
		 model.addAttribute("invalidOperation","You are perform invalid operation plese login agin!!!");
		 return "Login";
	 }
	}

}
