package com.cg.validator;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Component
public class EmployeeSearchValidator {
	@NotEmpty(message="Id required")
	@Pattern(regexp="^(0|[1-9][0-9]*)$", message="Id should be number Only!!!")	
	private String empId;

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}
	

}
