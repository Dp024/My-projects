package com.cg.validator;

import java.io.Serializable;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Component
public class UserLoginValidator implements Serializable {

/**
	 * 
	 */
private static final long serialVersionUID = 1L;
@NotEmpty(message="user name required")
private String userName;
@NotEmpty(message="password required")
private String password;
@NotEmpty(message="select Team member or Manager")
private String userType;
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getUserType() {
	return userType;
}
public void setUserType(String userType) {
	this.userType = userType;
}
public UserLoginValidator() {
	super();
	// TODO Auto-generated constructor stub
}


}
