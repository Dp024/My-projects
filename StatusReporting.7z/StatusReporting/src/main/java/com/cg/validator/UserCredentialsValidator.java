package com.cg.validator;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Component
public class UserCredentialsValidator {

@NotEmpty
private String userName;
@NotEmpty(message="Password required")
private String password;

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public String getUserName() {
	return userName;
}

public void setUserName(String userName) {
	this.userName = userName;
}

/*public void setUserName(String userName) {
	this.userName = userName;
}
*/

}
