package com.cg.service;

import com.cg.validator.UserLoginValidator;

public interface ILoginService {
public String userType(UserLoginValidator userLogin);
public int updateUserCredentials(String userName, String password);
}
