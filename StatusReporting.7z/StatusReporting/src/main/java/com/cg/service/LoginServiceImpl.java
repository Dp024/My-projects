package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ILoginDAO;
import com.cg.model.Employee;
import com.cg.model.EmployeeCredentials;
import com.cg.validator.UserLoginValidator;

@Service
public class LoginServiceImpl implements ILoginService {

    @Autowired
    private ILoginDAO loginDao;
    @Autowired
    private EmployeeCredentials employeeCredentials;
    @Autowired
    private Employee emp;
	@Override
	public String userType(UserLoginValidator userLogin) {
		emp.setRole(userLogin.getUserType());
		employeeCredentials.setUserName(userLogin.getUserName());
		employeeCredentials.setPassword(userLogin.getPassword());
		employeeCredentials.setEmployee(emp);
		
		return loginDao.roleType(employeeCredentials);
	
	}
	@Override
	public int updateUserCredentials(String userName, String password) {
		
		return loginDao.updateUserCredentials(userName, password);
	}

}

