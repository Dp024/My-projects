package com.fundsbank.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fundsbank.entities.Complaint;
import com.fundsbank.exception.DataException;
import com.fundsbank.service.CustomerServiceImpl;




@Controller
public class CustomerController {
    static List<String> categories;
	
	static{
		categories = new ArrayList<String>();
		categories.add("Internet Banking");
		categories.add("General Banking");
		categories.add("Others");
	}
	@Autowired
	CustomerServiceImpl service;
	
	@RequestMapping(value="home", method=RequestMethod.GET)
	public String loginForm(Model model){
		
		Complaint camplaint = new Complaint();
		model.addAttribute("complaint", camplaint);
		model.addAttribute("categories", categories);
		return "raiseComplaint";
	}
	@RequestMapping(value="RegisterComplaint", method=RequestMethod.POST)
	@ExceptionHandler(DataException.class)
	public String logComplaint(@ModelAttribute @Valid Complaint complaint, BindingResult result, Model model){
		
		if(result.hasErrors()){
			model.addAttribute("categories", categories);
			return "raiseComplaint";
		}else{
			Integer raiseComplaint = service.registerComplaint(complaint);
			if(null != raiseComplaint){
				model.addAttribute("complaintId", raiseComplaint);
			}
			return "success";
		}
	}
	@RequestMapping(value="complaintStatus", method=RequestMethod.GET)
	public String checkStatusForm(Model model){
		Complaint camplaint = new Complaint();
		model.addAttribute("complaint", camplaint);
		return "checkStatus";
	}
	@RequestMapping(value="checkStatus", method=RequestMethod.GET)
	public String checkStatus(@ModelAttribute("complaint") Complaint complaint, BindingResult result, Model model){
		
		if (result.hasErrors()) {
			  if(0 == complaint.getComplaintId()){
				  model.addAttribute("complaintidmissed", "Please provide the complaint Id!");
			  }
			return "checkStatus";
		} else {
			Complaint complaint1 = service.checkComplaintStatus(complaint.getComplaintId());
			if (null != complaint1) {
				model.addAttribute("modeldata", complaint1);
			} else {
				model.addAttribute("complaintnotexist",
						"Complaint not exist for given complaint Id");
			}
			return "checkStatus";
		}
	
	
	}
}
