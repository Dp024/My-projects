package com.fundsbank.dao;

import com.fundsbank.entities.Complaint;

public interface ICustomerDAO {
    public int insertComplaintData(Complaint complaint);
	public Complaint checkStatusByComplaintId(int complaintId);
}
