package com.fundsbank.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fundsbank.entities.Complaint;
import com.fundsbank.exception.DataException;



@Component
public class CustomerDAOImpl implements ICustomerDAO{
 
  @Autowired
  EntityManagerFactory entityManagerFactoryBean;
  EntityTransaction transaction;
  Integer identifier;
  @Override
  public int insertComplaintData(Complaint complaint) {
	  try{
			EntityManager createEntityManager = entityManagerFactoryBean.createEntityManager();
			transaction = createEntityManager.getTransaction();
			transaction.begin();
			createEntityManager.persist(complaint);
			transaction.commit();
			identifier = complaint.getComplaintId();
			}catch(Exception e){
				System.out.println("Exception in data persistence");
				transaction.rollback();
				throw new DataException(e.getMessage());
			}finally{
				entityManagerFactoryBean.close();
			}
			return identifier;
	}

	@Override
	public Complaint checkStatusByComplaintId(int complaintId) {
		Complaint complaint = new Complaint();
		try{
		EntityManager createEntityManager = entityManagerFactoryBean.createEntityManager();
		complaint = createEntityManager.find(Complaint.class, complaintId);
		}catch(Exception e){
			System.out.println("Exception : getComplaintStatus :" + e);
		}finally{
			entityManagerFactoryBean.close();
		}
		return complaint;
	}
	}


	


