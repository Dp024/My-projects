package com.fundsbank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fundsbank.dao.CustomerDAOImpl;
import com.fundsbank.entities.Complaint;



@Component
public class CustomerServiceImpl implements ICustomerService {
	@Autowired
	CustomerDAOImpl dao;
	
	@Override
	public int registerComplaint(Complaint complaint) {
		if("Internet Banking".equals(complaint.getCategory())){
			complaint.setPriority("High");
		}else if("General Banking".equals(complaint.getCategory())){
			complaint.setPriority("Medium");
		}else if("Others".equals(complaint.getCategory())){
			complaint.setPriority("Low");
		}
		int addComplaint = dao.insertComplaintData(complaint);
		
		return addComplaint;
}

	@Override
	public Complaint checkComplaintStatus(int complaintId) {
       
		Complaint complaint = dao.checkStatusByComplaintId(complaintId);
		
		return complaint;
	}
	

}
