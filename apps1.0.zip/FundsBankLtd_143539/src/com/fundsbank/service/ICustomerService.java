package com.fundsbank.service;

import com.fundsbank.entities.Complaint;


public interface ICustomerService {

	public int registerComplaint(Complaint compalint);
	
	public Complaint checkComplaintStatus(int complaintId);
}
