package com.dp;

import java.io.IOException;
import java.util.Date;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class ShapeFileIntoGeoJSON  {
	public static void  shapeFileIntoGeojson(String fileName) throws IOException{
		final ZipFile file = new ZipFile(fileName);
		System.out.println("Iterating over zip file : " + fileName); 
		try { 
			final Enumeration<? extends ZipEntry> entries = file.entries(); 
			while (entries.hasMoreElements()) 
			{ 
				final ZipEntry entry = entries.nextElement(); 
				String entryName=entry.getName();
				
				if(entryName.substring(entryName.length()-4).equals(".shp")){
				 
					System.out.printf("File: %s Size %d Modified on %TD %n", entry.getName(), entry.getSize(), new Date(entry.getTime()));
					String[] cmd = {"-t_srs", "CRS:84", "-f", "GeoJSON","sampledata.geojson",entryName};
                    Ogr2Ogr.main(cmd);
					
					
				}
				//extractEntry(entry, file.getInputStream(entry)); 
			} 
			//System.out.printf("Zip file %s extracted successfully in %s", FILE_NAME, OUTPUT_DIR); 
			} finally 
			{ 
				file.close(); 
			}
} 
	
	public static void main(String[] args) throws IOException{
		shapeFileIntoGeojson("C:\\Users\\Professional\\Desktop\\shape file uploader\\shapefile.zip");
	}

}
